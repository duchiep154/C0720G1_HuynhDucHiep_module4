package vn.codegym.session;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CookieSessionApplicationTests {

    @Test
    void contextLoads() {
    }

}
