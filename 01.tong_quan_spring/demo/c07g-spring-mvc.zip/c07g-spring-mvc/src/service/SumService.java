package service;

import org.springframework.stereotype.Service;


public interface SumService {
    int sum(int a, int b);
}
